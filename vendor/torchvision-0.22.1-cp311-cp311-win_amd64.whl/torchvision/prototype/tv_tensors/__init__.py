from ._label import Label, OneHotLabel
