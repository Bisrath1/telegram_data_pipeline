# alias to latest
from dbt.artifacts.schemas.catalog.v1.catalog import *  # noqa
from dbt_common.contracts.metadata import (
    CatalogKey,
    CatalogTable,
    ColumnMap,
    ColumnMetadata,
    StatsDict,
    StatsItem,
    TableMetadata,
)
